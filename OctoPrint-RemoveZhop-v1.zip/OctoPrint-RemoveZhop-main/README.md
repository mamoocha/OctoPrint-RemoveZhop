# OctoPrint-RemoveZhop
Removes small Z-hop movements from G-code live during printing.
